<html>
<head>
   
</head>
<style>
 
 firstPost
</style>
 
<h1> Laravel Many to Many Polymorphic Example </h1>
 
<h3> Tags associated with First Post </h3>
 
<?php $__currentLoopData = $firstPost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $firstPost_tags): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li> 
 
    <?php echo e($firstPost_tags->tag_name); ?>  
 
</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<h3> Tags associated with Second Post </h3>
 
<?php $__currentLoopData = $secondPost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $secondPost_tags): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li> 
 
    <?php echo e($secondPost_tags->tag_name); ?>  
 
</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<h3> Tags associated with First Video </h3>
 
<?php $__currentLoopData = $firstVideo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $firstVideo_tags): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li> 
 
    <?php echo e($firstVideo_tags->tag_name); ?>  
 
</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<h3> Tags associated with Second Video </h3>
 
<?php $__currentLoopData = $secondvideo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $secondVideo_tags): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li> 
 
    <?php echo e($secondVideo_tags->tag_name); ?>  
 
</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 
 
</body>
</html><?php /**PATH /Users/hardikparsania_mac/Desktop/web_demonuts/laramanytomanypoly/laramanytomanypoly/resources/views/index.blade.php ENDPATH**/ ?>
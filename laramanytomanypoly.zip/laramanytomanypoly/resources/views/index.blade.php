<html>
<head>
   
</head>
<style>
 
 firstPost
</style>
 
<h1> Laravel Many to Many Polymorphic Example </h1>
 
<h3> Tags associated with First Post </h3>
 
@foreach ($firstPost as $firstPost_tags)
<li> 
 
    {{ $firstPost_tags->tag_name}}  
 
</li>
@endforeach

<h3> Tags associated with Second Post </h3>
 
@foreach ($secondPost as $secondPost_tags)
<li> 
 
    {{ $secondPost_tags->tag_name}}  
 
</li>
@endforeach

<h3> Tags associated with First Video </h3>
 
@foreach ($firstVideo as $firstVideo_tags)
<li> 
 
    {{ $firstVideo_tags->tag_name}}  
 
</li>
@endforeach

<h3> Tags associated with Second Video </h3>
 
@foreach ($secondvideo as $secondVideo_tags)
<li> 
 
    {{ $secondVideo_tags->tag_name}}  
 
</li>
@endforeach
 
 
</body>
</html>
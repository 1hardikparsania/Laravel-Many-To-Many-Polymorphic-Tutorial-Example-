<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Post;
use App\Video;
use App\Tag;

class ManymanypolyController extends Controller
{
    //
    public function manymanypoly()
    {

        $first_post = Post::find(1);
        $firstPost = $first_post->tags;	

        $second_post = Post::find(2);
        $secondPost = $second_post->tags;

        $first_video = Video::find(1);
        $firstVideo = $first_video->tags;	

        $second_video = Video::find(2);
        $secondvideo= $second_video->tags;
        //dd($firstPost);

        return view('index',compact('firstPost','secondPost','firstVideo','secondvideo'));

    }
}
